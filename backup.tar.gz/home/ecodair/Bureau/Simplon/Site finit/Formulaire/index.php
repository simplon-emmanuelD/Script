<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<titel> Mon formulaire</title>
</head>

<body>
<p>
<a href="bonjour.php?nom=Manu&samp;prenom=Manu&manu">dis-moi bonjours </a>

</p>

</body>
</tml>