<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<titel> Mon formulaire</title>
</head>

<body>
<p>
bonjours <?php echo $_GET['nom']; ? ><?php echo $_GET['prenom'] ?>

</p>

</body>
</tml>