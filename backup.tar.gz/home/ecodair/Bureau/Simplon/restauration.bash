#!/bin/bash

sudo apt-get update
sudo apt-get install dselect
sudo dselect update
sudo dpkg --set-selections < liste-des-paquets
sudo apt-get -u dselect-upgrade