#!/bin/sh

echo "------------------------------------------------------";
echo "- Restauration du système";
echo "------------------------------------------------------";
echo "";

echo "Récupération et extraction de l'archive";

cd / 
# On extrait les répertoires archivés en ne mettant PAS le / devant, comme expliqué tout à l'heure.
sudo tar -xvzf sav.tar.gz 
echo "------------------------------------------------------";
echo "";

echo "### Fin de l'extraction des fichiers.  ###";

