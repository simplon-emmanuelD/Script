#!/bin/sh

dpkg --get-selections > liste-des-paquets
